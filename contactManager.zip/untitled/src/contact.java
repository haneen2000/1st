public class contact {
    String name;
    String email;
    String phoneNO;
}
